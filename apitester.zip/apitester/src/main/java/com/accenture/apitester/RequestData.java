package com.accenture.apitester;

/**
 * Created by sr250345 on 2/7/17.
 */
public class RequestData {

    private String method;
    private String url;
    private String payload;

    public RequestData()
    {

    }
    public RequestData(String method, String url, String payload) {
        this.method = method;
        this.url = url;
        this.payload = payload;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getPayload() {
        return payload;
    }

    public void setPayload(String payload) {
        this.payload = payload;
    }
}
