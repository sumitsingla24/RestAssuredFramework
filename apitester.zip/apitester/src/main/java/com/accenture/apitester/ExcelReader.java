package com.accenture.apitester;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created by sr250345 on 2/7/17.
 */

public class ExcelReader {

    private static final String excelFilePath = "C:\\HPDP\\apitester\\testdata.xlsx";


    public static void main(String args[])
    {
        read();
    }
    public static List<RequestData> read()
    {
        List<RequestData> requestDataList = new ArrayList<RequestData>();
        try {

            FileInputStream inputStream = new FileInputStream(new File(excelFilePath));

            Workbook workbook = new XSSFWorkbook(inputStream);
            Sheet firstSheet = workbook.getSheetAt(0);
            Iterator<Row> iterator = firstSheet.iterator();


            while (iterator.hasNext())
            {
                Row nextRow = iterator.next();
                Cell mCell = nextRow.getCell(0);
                if(mCell != null)
                {
	                String method = mCell.getStringCellValue();
	                String url = nextRow.getCell(1).getStringCellValue();
	                String payload = nextRow.getCell(2).getRichStringCellValue().getString();
	                
	                //String encodedPayload = new String(payload.getBytes(),"UTF-8");
	                
	                RequestData requestData = new RequestData(method, url, payload);
	                requestDataList.add(requestData);
                }
                else
                {
                	break;
                }

            }
            workbook.close();
            inputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            return requestDataList;
        }
    }
}
