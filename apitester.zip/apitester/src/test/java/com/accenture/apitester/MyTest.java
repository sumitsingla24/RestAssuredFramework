package com.accenture.apitester;


import org.junit.Test;



import com.jayway.restassured.RestAssured;
import com.jayway.restassured.config.SSLConfig;
import com.jayway.restassured.response.Response;

import org.hamcrest.Matchers.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.jayway.restassured.RestAssured.given;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

/**
 * Created by sr250345 on 2/7/17.
 */
public class MyTest {

	ExtentReports report;
	ExtentTest logger; 
	//WebDriver driver;

    /*@Test
    public void makeSureThatGoogleIsUp() {

        //given().when().get("http://www.google.com").then().log().all().statusCode(200);
    }*/

    @Test
    public void testPosts() {
    	report=new ExtentReports("C:\\Report\\apitester.html");

    	logger=report.startTest("APITesting");

        List<RequestData> requestDataList = ExcelReader.read();
        Map<String, String> headersMap = new HashMap<String, String>();
        headersMap.put("Authorization", "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6InNFa01ja2RuczM3UjgwUW1waVpOOUtxTzBPUSJ9.eyJpc3MiOiJ1cm46ZmVkZXJhdGlvbjphY2NlbnR1cmUiLCJhdWQiOiJodHRwczovL2hwZHBhbWludHN2ci5jaW9zdGFnZS5hY2NlbnR1cmUuY29tIiwibmJmIjoxNDg5MDQyODIzLCJleHAiOjE0ODkwNDY0MjMsIm5hbWVpZCI6Im5hdmVlbi5tb2hhbmRhc0BhY2NlbnR1cmUuY29tIiwidXBuIjoibmF2ZWVuLm1vaGFuZGFzQGFjY2VudHVyZS5jb20iLCJ1bmlxdWVfbmFtZSI6Im5hdmVlbi5tb2hhbmRhc0BhY2NlbnR1cmUuY29tIiwiZW1haWwiOiJuYXZlZW4ubW9oYW5kYXNAYWNjZW50dXJlLmNvbSIsImh0dHBzOi8vZmVkZXJhdGlvbi1zdHMuYWNjZW50dXJlLmNvbS9zY2hlbWFzL2NsYWltcy8xL2VudGVycHJpc2VpZCI6Im5hdmVlbi5tb2hhbmRhcyIsImh0dHBzOi8vZmVkZXJhdGlvbi1zdHMuYWNjZW50dXJlLmNvbS9zY2hlbWFzL2NsYWltcy8xL3Blb3BsZWtleSI6IjEwNzkxNjciLCJodHRwczovL2ZlZGVyYXRpb24tc3RzLmFjY2VudHVyZS5jb20vc2NoZW1hcy9jbGFpbXMvMS9wZXJzb25uZWxudW1iZXIiOiIxMTAwMzA1NCIsImF1dGhtZXRob2QiOiJodHRwOi8vc2NoZW1hcy5taWNyb3NvZnQuY29tL3dzLzIwMDgvMDYvaWRlbnRpdHkvYXV0aGVudGljYXRpb25tZXRob2QvcGFzc3dvcmQiLCJhdXRoX3RpbWUiOiIyMDE3LTAzLTA5VDA3OjAwOjIzLjM2MFoifQ.g4A0i7sVHoXRC0e4lr4TXsYSuHBBsvvTJvUBvjUxPDjKdPgtQeRzIQzlsBnmZK_LVMRnHvwTJUPoJR7alpjbILgIyskednbcA2uWOFB97Mg0QvEHk_i1sx8vQoRuEEZenTkzTAnTTLUsZpEfVTW7TsyoK5Ggsb4Kkpx8ZjSzzBVIRKq1eVdxeKFkSZDH7i5TQ3IHyRP1BK1aVkZfS-0Q6WxCAXs2qa_Nid9ku3VBCPZKJvw-QyHWAuzO9e_7_HXsXorWxRSjUB7MIRoGLUkp5qYUCwazB9-ybxLo1BYUsowiQ6lZY3sFVdJclcDNUfN3RhNVX5kcLPTC70V6SB8ISQ");
        for(int k=1;k<requestDataList.size();k++)				
		{
        	RequestData r =  requestDataList.get(k);
            System.out.println("------------------------------------");
            try {
            	
                if(r.getMethod().equals("GET")) {
                    given()
                            .contentType("application/json")
                            .headers(headersMap)
                            .body(r.getPayload())
                            .log().all()

                            .when()
                            .get(r.getUrl())

                            .then()
                            .statusCode(200);
                }else
                {
                	Response res = given().config(RestAssured.config().sslConfig(SSLConfig.sslConfig().allowAllHostnames().relaxedHTTPSValidation()))


                            .contentType("application/xml")
                            .headers(headersMap)
                            .body(r.getPayload())
                            .log().all()
                            .when()
                            .post(r.getUrl());
                	
                	System.out.println(res.getStatusCode());
                	
                	
                	logger.log(LogStatus.PASS, "Status code :"+ res.getStatusCode());
                	logger.log(LogStatus.INFO,"Url info"+ r.getUrl());
                	report.endTest(logger);
                	report.flush();

                            //.then()
                            //.statusCode(202);
                }
            }catch(Exception e)
            {
                e.printStackTrace();
                
            }
        }
        //given().headers(headersMap).log().all().when().get("http://jsonplaceholder.typicode.com/posts").then().statusCode(200);
    }

}
